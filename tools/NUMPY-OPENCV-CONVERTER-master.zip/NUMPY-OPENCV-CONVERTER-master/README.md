
# NUMPY-OPENCV-CONVERTER

FORKED FROM:<br/>
https://github.com/spillai/numpy-opencv-converter<br/>
https://github.com/GarrickLin/numpy-opencv-converter <br/>

There were a few compatiibility issues with regards to the CMAKE files. I've just fixed these issues such that the installation is quick and easy. <br/>

STEPS:<br/>
* Clone the repository.
* Delete the existing build folder.
* Create a new build folder and run CMAKE from inside it.
* USE PYBOOST-OPENCV-CONVERTER FOR PYTHON3 and NUMPY-OPENCV-CONVERTER for PYTHON2

